importer
========

.. automodule:: importer

   
   
   .. rubric:: Functions

   .. autosummary::
   
      file_parser
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      TempCategory
   
   

   
   
   