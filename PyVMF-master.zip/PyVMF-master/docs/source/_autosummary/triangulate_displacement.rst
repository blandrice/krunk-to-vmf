triangulate\_displacement
=========================

.. automodule:: triangulate_displacement

   
   
   .. rubric:: Functions

   .. autosummary::
   
      triangulate_displacement
   
   

   
   
   

   
   
   