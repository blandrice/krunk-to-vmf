PyVMF.Matrix
============

.. currentmodule:: PyVMF

.. autoclass:: Matrix

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Matrix.__init__
      ~Matrix.column
      ~Matrix.copy
      ~Matrix.export
      ~Matrix.export_attr
      ~Matrix.export_children
      ~Matrix.extract_dic
      ~Matrix.get
      ~Matrix.ids
      ~Matrix.inv_rect
      ~Matrix.rect
      ~Matrix.row
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Matrix.ID
   
   