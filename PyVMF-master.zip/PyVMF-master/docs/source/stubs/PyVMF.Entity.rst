PyVMF.Entity
============

.. currentmodule:: PyVMF

.. autoclass:: Entity

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Entity.__init__
      ~Entity.copy
      ~Entity.export
      ~Entity.export_children
      ~Entity.ids
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Entity.ID
      ~Entity.NAME
   
   