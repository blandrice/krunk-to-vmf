PyVMF.DispVert
==============

.. currentmodule:: PyVMF

.. autoclass:: DispVert

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DispVert.__init__
      ~DispVert.copy
      ~DispVert.export
      ~DispVert.export_children
      ~DispVert.ids
      ~DispVert.set
      ~DispVert.set_alpha
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DispVert.ID
   
   