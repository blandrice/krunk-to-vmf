PyVMF.DispInfo
==============

.. currentmodule:: PyVMF

.. autoclass:: DispInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~DispInfo.__init__
      ~DispInfo.copy
      ~DispInfo.export
      ~DispInfo.export_children
      ~DispInfo.ids
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~DispInfo.ID
      ~DispInfo.NAME
   
   