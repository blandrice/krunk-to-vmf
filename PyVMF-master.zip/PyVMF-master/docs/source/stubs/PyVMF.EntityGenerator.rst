PyVMF.EntityGenerator
=====================

.. currentmodule:: PyVMF

.. autoclass:: EntityGenerator

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~EntityGenerator.__init__
      ~EntityGenerator.light
      ~EntityGenerator.prop_static
   
   

   
   
   