PyVMF.SolidGenerator
====================

.. currentmodule:: PyVMF

.. autoclass:: SolidGenerator

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SolidGenerator.__init__
      ~SolidGenerator.cube
      ~SolidGenerator.dev_material
      ~SolidGenerator.displacement_triangle
      ~SolidGenerator.room
   
   

   
   
   