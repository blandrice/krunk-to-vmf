PyVMF
============

.. automodule:: PyVMF
   :members:
   :undoc-members:
   :show-inheritance:

.. autosummary::
   :toctree: stubs
   
   VMF
   Solid
   SolidGenerator
   Entity
   EntityGenerator
   Side
   Vertex
   DispInfo
   DispVert
   Matrix
